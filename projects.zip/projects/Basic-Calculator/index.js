const buttonsE1= document.querySelectorAll("button");
const inputfield=document.getElementById("result");

for( let i=0; i<buttonsE1.length; i++){
  buttonsE1[i].addEventListener("click", () =>{
      const buttonvalue=buttonsE1[i].textContent;
  if(buttonvalue==="C"){
    clearResult();
}
else if(buttonvalue==="="){
    calculateResult();
}
else{
    appendResult(buttonvalue);
}
    });
}
function clearResult() {
  inputfield.value = "";
}

function calculateResult() {
  inputfield.value=eval(inputfield.value);
}

function appendResult(buttonvalue) {
    inputfield.value += buttonvalue;
}