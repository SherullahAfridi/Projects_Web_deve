const apikey = "0b7973ef0922f77204dc31a940a0f327";
const weatherDataEl = document.getElementById("weather-data");
const cityInputEl = document.getElementById("City-input");
const formEl = document.querySelector("form");

formEl.addEventListener("submit", (event) => {
    event.preventDefault();
    const city = cityInputEl.value.trim();
    if (city) {
        getWeatherData(city);
    }
});

async function getWeatherData(city) {
    try {
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apikey}&units=metric`
        );

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Error fetching weather");
        }

        const data = await response.json();

        const temperature = Math.round(data.main.temp);
        const description = data.weather[0].description;
        const icon = data.weather[0].icon;

        const details = [
            `Feels Like: ${Math.round(data.main.feels_like)}°C`,
            `Humidity: ${data.main.humidity}%`,
            `Wind Speed: ${data.wind.speed} m/s`
        ];

        weatherDataEl.querySelector(".icon").innerHTML = 
            `<img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="Weather Icon">`;

        weatherDataEl.querySelector(".temperature").textContent = `${temperature}°C`;
        weatherDataEl.querySelector(".description").textContent = description;
        weatherDataEl.querySelector(".Details").innerHTML = details
            .map(detail => `<div>${detail}</div>`)
            .join("");
    } catch (error) {
        weatherDataEl.querySelector(".icon").innerHTML = "";
        weatherDataEl.querySelector(".temperature").textContent = "";
        weatherDataEl.querySelector(".description").textContent = error.message;
        weatherDataEl.querySelector(".Details").innerHTML = "";
        console.error("Weather fetch error:", error);
    }

}
getWeatherData("Los Angeles,US");
getWeatherData("Lahore,PK");
getWeatherData("Peshawar,PK");
getWeatherData("New York,US");
getWeatherData("Tokyo,JP");
getWeatherData("London,UK");
getWeatherData("Paris,FR");
getWeatherData("Berlin,DE");
getWeatherData("Sydney,AU");

